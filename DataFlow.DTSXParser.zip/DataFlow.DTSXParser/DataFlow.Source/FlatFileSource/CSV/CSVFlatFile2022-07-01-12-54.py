import sys
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
from pyspark.sql import SparkSession
from pyspark.sql.types import *
import pyodbc
import pandas as pd

master = "local"
appName = "CSV"
conf = SparkConf() \
.setAppName(appName) \
.setMaster(master)
sc = SparkContext.getOrCreate(conf = conf)
sqlContext = SQLContext(sc)
spark = SparkSession.builder.getOrCreate()
data = pd.read_csv(r'I:\SK\test.csv')
df = pd.DataFrame(data)

df['ID'] = pd.to_numeric(df['ID'])
df['Name'] = df['Name'].astype(str)
df['CreateDate'] = pd.to_datetime(df['CreateDate'])


server_name = 'AZR-BIDT-P'
database = 'DnA-Solutions'
table = ''
user = ''
password = ''


conn = pyodbc.connect(f'DRIVER={{ODBC Driver 18 for SQL Server}};SERVER={server_name};DATABASE={database};UID={user};PWD={password};TrustServerCertificate=Yes;')


cursor = conn.cursor()

for row in df.itertuples():
    cursor.execute('''
INSERT INTO {table} (Name, ID, CreateDate)
VALUES (?,?,?)
''',
row.Name, row.ID, row.CreateDate
)
conn.commit()
